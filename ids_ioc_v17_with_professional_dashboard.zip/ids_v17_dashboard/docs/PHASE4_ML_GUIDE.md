# Phase 4: Deep Learning / ML Integration Guide

## Where we are

Phase 4 has started, but the real deep-learning model is not connected yet because we still need the doctor's model details.

The new code adds an ML bridge:

```text
PacketCapture
   ├── IOC queue -> IOC workers -> IOC alerts
   └── ML queue  -> ML workers  -> ML features / ML alerts
```

## New file

```text
ml_engine.py
```

This file does three things:

1. Converts packets into numeric features.
2. Can print extracted features using `features-only` mode.
3. Can load a model later and create `ML_MATCH` alerts.

## Starter ML features

Current starter feature vector:

```text
protocol_number
src_port
dst_port
packet_length
```

Protocol numbers:

```text
ICMP = 1
TCP  = 6
UDP  = 17
OTHER = 0
```

This is not necessarily the final feature list. Your doctor's model may need flow-based features such as duration, packet count, byte count, flags, averages, or CICIDS-style columns.

## How to run feature-only mode

Use this first. It does not require a model.

```bash
sudo .venv/bin/python main.py --iface eth0 --ml-mode features-only --ml-debug-every 1 --bpf icmp
```

From attacker VM:

```bash
ping 192.168.10.1
```

Expected output example:

```text
ML_FEATURES worker=0 packet=ICMP 192.168.10.10:- -> 192.168.10.1:- len=84 features={'protocol_number': 1.0, 'src_port': 0.0, 'dst_port': 0.0, 'packet_length': 84.0}
```

## How to run prediction mode later

Only after you have a model file:

```bash
sudo .venv/bin/python main.py --iface eth0 --ml-mode predict --ml-model-path models/model.joblib --ml-threshold 0.8
```

Supported starter formats:

```text
.pkl
.joblib
.keras
.h5
```

For `.keras` or `.h5`, TensorFlow must be installed in the venv.

## What we need from the doctor/model

Before real integration, we need:

1. Model file type: `.pkl`, `.joblib`, `.h5`, `.keras`, `.pt`, etc.
2. Exact input feature names.
3. Exact feature order.
4. Input shape, for example `(1, 4)` or `(1, 78)`.
5. Whether the model expects packet-level or flow-level data.
6. Label meaning: does output `1` mean attack or normal?
7. Threshold recommendation, if available.
8. Any scaler/preprocessor file, for example `scaler.pkl`.

## Important

The current ML mode is safe for learning. It does not change the network by itself. IPS blocking only happens if you also enable:

```bash
--ips-mode enforce
```

Start with ML feature-only mode, then model prediction, then optional IPS enforcement.
