# V17 Professional Dashboard Guide

This version adds a GUI dashboard to the v17 IDS/IPS project.

## What the dashboard shows

The dashboard has two pages:

1. **Alerts page**
   - Reads `logs/alerts.jsonl`
   - Shows IOC, ML, IPS-triggering, and correlated alerts
   - Shows where alerts are coming from: IOC Engine, CICIDS ML Model, Correlation Engine, etc.
   - Includes charts:
     - Alert timeline by timestamp
     - Alert source/engine distribution
     - Alert type distribution
     - Top alerting source IPs

2. **All Logs page**
   - Reads `logs/traffic.jsonl` and merges alert records
   - Shows observed traffic and alert logs together
   - Includes charts:
     - Log timeline by timestamp
     - Protocol distribution
     - Top source IPs
     - Top destination IPs

The page auto-refreshes every 3 seconds.

## Important

The All Logs page is filled only if you run the IDS with:

```bash
--log-traffic
```

Without `--log-traffic`, the Alerts page still works, but the All Logs page will not show packet traffic.

## Run the IDS with dashboard logs

Terminal 1:

```bash
cd ~/Desktop/IDS
source .venv/bin/activate
sudo .venv/bin/python main.py \
  --iface eth0 \
  --log-traffic \
  --ips-mode dry-run \
  --ml-mode predict \
  --debug-decisions
```

Or use:

```bash
./run_ids_with_dashboard_logs.sh
```

## Run the dashboard

Terminal 2:

```bash
cd ~/Desktop/IDS
source .venv/bin/activate
python dashboard.py --host 0.0.0.0 --port 8000
```

Or use:

```bash
./run_dashboard.sh
```

Open in browser:

```text
http://127.0.0.1:8000
```

From another VM on the same lab network:

```text
http://192.168.10.1:8000
```

## API endpoints

The dashboard uses API endpoints:

```text
/api/alerts   -> reads logs/alerts.jsonl
/api/traffic  -> reads logs/traffic.jsonl
/api/logs     -> merges traffic + alerts
/api/summary  -> chart and metric data
```

You can open these URLs in the browser to see raw JSON.

## Presentation explanation

You can say:

> The IDS writes confirmed security alerts to `alerts.jsonl` and all observed packet logs to `traffic.jsonl`. The dashboard exposes API endpoints that read these JSONL files and returns them to the browser as JSON. The frontend auto-refreshes every 3 seconds and creates Splunk-like timeline charts, source distribution panels, and searchable event tables.

