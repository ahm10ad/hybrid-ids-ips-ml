# Phase 4F — ML-only slow HTTP/Slowloris tuning

This version does **not** add a separate Slowloris rule detector.

The fix is inside the ML feature pipeline:

1. Keep slow HTTP connections alive longer before finalizing the flow.
2. Finalize active flows every 30 seconds so the demo can alert while traffic is still running.
3. Use CICIDS-like normalizer values for web DoS/Slowloris features.
4. Remap common lab HTTP ports such as 8080, 8000, and 8443 to port 80 inside the ML feature vector only, because the uploaded CICIDS model learned web DoS mainly on HTTP port 80.

The original packet fields, logs, and IPS fields still show the real port, such as 8080.
Only the ML feature vector uses the port normalization.

Recommended lab run:

```bash
sudo .venv/bin/python main.py --iface eth0 --debug-decisions --bpf "ip"
```

Expected ML output for the slow HTTP lab pattern after enough packets/duration:

```text
ML_PREDICTION class=DoS Slowhttptest ...
ML_ALERT class=DoS Slowhttptest ...
```

If your server runs on a different lab HTTP port, add it:

```bash
sudo .venv/bin/python main.py --iface eth0 --debug-decisions --bpf "ip" --ml-http-remap-ports "8080,8000,8443,9000"
```

To disable port remapping:

```bash
sudo .venv/bin/python main.py --iface eth0 --debug-decisions --bpf "ip" --ml-http-remap-ports ""
```

Important: this still depends on the uploaded model and the approximate live normalizer. The best long-term fix is to use the exact scaler/preprocessor used during training or retrain/fine-tune with your own labeled lab PCAPs.
