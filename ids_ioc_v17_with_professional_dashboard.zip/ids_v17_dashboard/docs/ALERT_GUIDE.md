# Alert Guide

This file explains what each alert reason means.

## SRC_IP_BLACKLISTED

Example:

```text
SRC_IP_BLACKLISTED:192.168.10.10
```

Meaning: the source IP of the packet exists in `data/blacklist_ips.csv`.

Example packet:

```text
192.168.10.10 -> 192.168.10.1
```

The IDS is saying: traffic came from a blacklisted IP.

## DST_IP_BLACKLISTED

Example:

```text
DST_IP_BLACKLISTED:192.168.10.50
```

Meaning: the destination IP of the packet exists in `data/blacklist_ips.csv`.

Example packet:

```text
192.168.10.10 -> 192.168.10.50
```

The IDS is saying: traffic is going to a blacklisted IP.

## SRC_PORT_BLACKLISTED

Example:

```text
SRC_PORT_BLACKLISTED:4444
```

Meaning: the source port exists in `data/blacklist_ports.csv`.

This can happen, but it is less common than destination-port alerts because clients normally use random source ports.

## DST_PORT_BLACKLISTED

Example:

```text
DST_PORT_BLACKLISTED:4444
```

Meaning: the destination port exists in `data/blacklist_ports.csv`.

Example packet:

```text
192.168.10.10:51522 -> 192.168.10.1:4444
```

The IDS is saying: a device tried to connect to a blacklisted destination port.

## SUPPRESSED_BY_WHITELIST

This is not an alert. It appears only when you run with:

```bash
sudo .venv/bin/python main.py --iface eth0 --debug-decisions
```

Meaning: the packet matched a whitelisted IP, so the IDS ignored it.

## DUPLICATE_SUPPRESSED

This is not an alert. It appears only when you run with:

```bash
sudo .venv/bin/python main.py --iface eth0 --debug-decisions
```

Meaning: the packet matched an IOC, but the same alert happened recently, so deduplication suppressed it.

# Phase 3 IPS Messages

## IPS_DRY_RUN

Means the IPS module received an alert and would block the source IP, but the program is in dry-run mode.

Example:

```text
IPS_DRY_RUN would block source_ip=192.168.10.10
```

No firewall rule is added.

## IPS_BLOCK_APPLIED

Means enforce mode is active and an iptables DROP rule was added.

Example:

```text
IPS_BLOCK_APPLIED chain=INPUT source_ip=192.168.10.10
```

## IPS_BLOCK_REMOVED

Means a block expired or the program is cleaning up before exit.

Example:

```text
IPS_BLOCK_REMOVED chain=FORWARD source_ip=192.168.10.10
```

## IPS_BLOCK_ALREADY_EXISTS

Means the DROP rule already exists, so the program did not add another duplicate rule.
