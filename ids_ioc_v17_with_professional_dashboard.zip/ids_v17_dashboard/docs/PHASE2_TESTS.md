# Phase 2 Testing Guide

Use these tests only inside your own lab VMs.

## 1. Prove packet capture works

Run on the IDS VM:

```bash
sudo .venv/bin/python main.py --iface eth0 --debug-packets --bpf icmp
```

From the attacker VM:

```bash
ping 192.168.10.1
```

Expected result: even if there is no alert, you should see lines like:

```text
PACKET #1 ICMP 192.168.10.10:- -> 192.168.10.1:- len=84
```

This proves traffic is reaching the IDS.

## 2. Test blacklisted IP detection

Edit `data/blacklist_ips.csv`:

```csv
ip
192.168.10.10
```

Run:

```bash
sudo .venv/bin/python main.py --iface eth0 --debug-packets
```

From attacker:

```bash
ping 192.168.10.1
```

Expected alert:

```text
ALERT ... ICMP 192.168.10.10:- -> 192.168.10.1:- ... SRC_IP_BLACKLISTED:192.168.10.10
```

## 3. Test blacklisted port detection

Edit `data/blacklist_ports.csv`:

```csv
port
4444
```

On the IDS VM, open a test listener in another terminal:

```bash
nc -lnvp 4444
```

Run the IDS:

```bash
sudo .venv/bin/python main.py --iface eth0 --dedup-mode exact
```

From the attacker VM:

```bash
nc -vz 192.168.10.1 4444
```

Expected alert:

```text
DST_PORT_BLACKLISTED:4444
```

## 4. Test whitelist behavior

Edit `data/blacklist_ips.csv`:

```csv
ip
192.168.10.10
```

Edit `data/whitelist_ips.csv`:

```csv
ip
192.168.10.10
```

Run:

```bash
sudo .venv/bin/python main.py --iface eth0 --debug-packets --debug-decisions
```

From attacker:

```bash
ping 192.168.10.1
```

Expected result: you should see captured packets and `SUPPRESSED_BY_WHITELIST`, but no alert.

Important: this is only a test. In a real IDS, do not whitelist the attacker IP.

## 5. Read saved alerts

Alerts are saved here:

```text
logs/alerts.jsonl
```

To watch alerts live:

```bash
tail -f logs/alerts.jsonl
```
