# ML-only real-life IDS runner

Use this runner for the lab demo when you want PortScan detection to come from the ML model only.

It enables:

- IOC detection from the CSV files
- CICIDS ML prediction using `models/CICIDS_baseline (2).h5`
- ML attack probability guard
- Alert writing
- IPS queue in dry-run mode by default

It does **not** start the old port-scan detector.

## Run

```bash
cd ~/Desktop/IDS/ids_ioc_starter
chmod +x run_real_life_ids.sh
sudo ./run_real_life_ids.sh eth0
```

If your capture interface is different:

```bash
sudo ./run_real_life_ids.sh eth1
```

## IPS modes

Safe dry-run:

```bash
sudo ./run_real_life_ids.sh eth0 dry-run
```

Alert only:

```bash
sudo ./run_real_life_ids.sh eth0 alert-only
```

Real blocking inside your own isolated lab only:

```bash
sudo ./run_real_life_ids.sh eth0 enforce
```

## Settings used for ML PortScan detection

```text
--ml-mode predict
--ml-flow-key-mode five-tuple
--flow-idle-timeout 3
--flow-active-timeout 10
--min-flow-packets 2
--ml-http-remap-ports ""
```

Expected output:

```text
ML_PREDICTION worker=0 class=PortScan confidence=...
ML_ALERT worker=0 class=PortScan confidence=...
```

## Logs

```bash
tail -f logs/ids_console_ml_only_real_life.log
tail -f logs/alerts_ml_only_real_life.jsonl
```
