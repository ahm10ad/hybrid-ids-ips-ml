# ML-only PortScan detection guide

This version removes the separate port-scan detector. The IDS still captures packets and builds 72 CICIDS-style flow features, but the alert must come from the uploaded ML model.

Run:

```bash
sudo ./run_real_life_ids.sh eth0
```

For PortScan/Nmap tests, this runner uses:

```text
--ml-flow-key-mode five-tuple
--flow-idle-timeout 3
--flow-active-timeout 10
--min-flow-packets 2
--ml-http-remap-ports ""
```

Why this helps the model:

- PortScan in CICIDS is usually a tiny TCP flow.
- The flow often has zero payload and a reset flag.
- CICIDS training rows encode these tiny reset flows with high normalized idle features.
- The live feature extractor now calibrates those CICIDS features before sending the vector to the model.

Expected output:

```text
ML_PREDICTION worker=0 class=PortScan confidence=...
ML_ALERT worker=0 class=PortScan confidence=...
```

If you only see `class=BENIGN`, check that you are sniffing the correct interface and that you are capturing both directions of the TCP scan traffic.
