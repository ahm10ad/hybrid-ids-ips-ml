# Phase 4B-D: Live CICIDS Deep-Learning Integration

## Current status

This version completes the first working code for:

- **Phase 4B:** Build live CICIDS-style flow features from captured packets.
- **Phase 4C:** Normalize those live flow features into 72 numeric values.
- **Phase 4D:** Send the 72 values to the doctor's 9-class CICIDS model and create ML alerts.

## Important limitation

The uploaded `train_CICIDS2017Multiclass_NumericFS.csv` and `test_CICIDS2017Multiclass_NumericFS.csv` are already normalized.
The original scaler/preprocessor was not uploaded.

Because of that, this project includes:

```text
models/live_feature_normalizer.json
```

This is an approximate live normalizer so the model can run end-to-end.
For best accuracy, ask for the real training preprocessor, usually named something like:

```text
preprocessor.pkl
scaler.pkl
minmax_scaler.pkl
```

## New files

```text
cicids_live_features.py
```

Builds 72 CICIDS-style flow features.

```text
ml_engine.py
```

Runs the live ML worker, finalizes flows, and sends features to the model.

```text
models/live_feature_normalizer.json
```

Approximate normalizer for live flow features.

## How live prediction works

Packets are not sent directly to the model.

The real flow is:

```text
PacketEvent
   ↓
FlowState
   ↓
72 raw CICIDS-style flow features
   ↓
72 normalized model inputs
   ↓
CICIDS_baseline (2).h5
   ↓
9-class prediction
   ↓
ML_FLOW_MATCH alert if non-BENIGN confidence >= threshold
```

## Test 1: see flow features only

Run on IDS VM:

```bash
sudo .venv/bin/python main.py --iface eth0 --ml-mode features-only --bpf icmp --flow-idle-timeout 3 --debug-packets
```

From attacker VM:

```bash
ping -c 4 192.168.10.1
```

Wait about 3 seconds after ping stops. You should see:

```text
ML_FLOW_FEATURES ... vector_len=72
```

## Test 2: run model prediction but print decisions

Run:

```bash
sudo .venv/bin/python main.py --iface eth0 --ml-mode predict --bpf icmp --flow-idle-timeout 3 --debug-decisions
```

From attacker VM:

```bash
ping -c 4 192.168.10.1
```

You should see something like:

```text
ML_PREDICTION class=BENIGN confidence=...
```

This may not create an alert if the class is BENIGN, because BENIGN alerts are suppressed by default.

## Test 3: force BENIGN predictions to become alerts for demonstration

Only use this for testing the alert pipeline:

```bash
sudo .venv/bin/python main.py --iface eth0 --ml-mode predict --bpf icmp --flow-idle-timeout 3 --debug-decisions --ml-alert-benign
```

Then ping again from attacker. You should see an ML alert saved in:

```text
logs/alerts.jsonl
```

## Test 4: combine IOC + ML

Add attacker IP to:

```text
data/blacklist_ips.csv
```

Example:

```csv
ip
192.168.10.10
```

Run:

```bash
sudo .venv/bin/python main.py --iface eth0 --ml-mode predict --bpf icmp --flow-idle-timeout 3 --debug-decisions
```

Now the IDS can produce:

- IOC alerts from the blacklist logic
- ML predictions from the deep-learning model

## Test 5: ML + IPS dry-run

Do not enforce blocking first. Use dry-run:

```bash
sudo .venv/bin/python main.py --iface eth0 --ml-mode predict --ips-mode dry-run --bpf icmp --flow-idle-timeout 3 --debug-decisions --ml-alert-benign
```

This shows what would be blocked, but does not change iptables.

## Notes for the final report

You can explain Phase 4 as:

1. The doctor’s model requires 72 CICIDS2017 flow features.
2. Live packets are grouped into bidirectional flows.
3. The system calculates duration, packet counts, byte counts, packet length statistics, IAT statistics, TCP flag counts, active/idle indicators, and flow rates.
4. Features are normalized into the model’s expected 0–1 range.
5. The model outputs one of 9 classes.
6. The IDS creates an ML alert when a non-BENIGN class passes the confidence threshold.

## Optional simulation test without live traffic

After installing requirements, run:

```bash
python simulate_live_ml_test.py
```

This creates fake ICMP packets, extracts a 72-value flow vector, and runs the model.
It is useful when you want to prove Phase 4B-D works before testing with real VM traffic.
