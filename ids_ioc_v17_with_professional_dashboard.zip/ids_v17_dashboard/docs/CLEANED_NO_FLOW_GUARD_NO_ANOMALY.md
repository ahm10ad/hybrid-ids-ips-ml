# Cleaned v17: Flow Guard and Anomaly Removed

This version removes:

- `flow_rate_guard.py`
- `anomaly_engine.py`
- Flow Rate Guard CLI options
- Isolation Forest / anomaly CLI options
- `scikit-learn` and `joblib` from `requirements.txt`

Kept:

- IOC blacklist/whitelist detection
- IPS alert-only / dry-run / enforce modes
- CICIDS supervised ML model
- ICMP skip in ML
- Per-class ML thresholds
- Smart flow key mode
- Alert correlation engine for remaining IDS/ML signals

Reason: this version is simpler to run on Kali and avoids extra dependency issues from `scikit-learn`.
