# Phase 3: IPS Blocking Tests

Phase 3 adds optional IPS behavior. The default is still safe IDS mode.

## New modes

```bash
--ips-mode alert-only
```

Default. Detects and logs alerts only. No firewall changes.

```bash
--ips-mode dry-run
```

Shows what the IPS would block, but does not change iptables.

```bash
--ips-mode enforce
```

Adds iptables DROP rules for the suspicious source IP.

## Important safety note

Start with dry-run first. Use enforce only inside your own lab network.

The Phase 3 beginner rule is:

```text
If an allowed IOC alert happens, block the packet source IP.
```

The rule is inserted into these chains by default:

```text
INPUT, FORWARD
```

- INPUT helps block traffic sent directly to the IDS machine.
- FORWARD helps block traffic passing through the IDS when it acts as a gateway/router.

## Test 1: Dry-run IPS

1. Add attacker IP to blacklist:

```bash
nano data/blacklist_ips.csv
```

Example:

```csv
ip
192.168.10.10
```

2. Run IDS with dry-run IPS:

```bash
sudo .venv/bin/python main.py --iface eth0 --ips-mode dry-run --debug-packets --bpf icmp
```

3. From attacker VM:

```bash
ping 192.168.10.1
```

Expected IDS output:

```text
ALERT ... SRC_IP_BLACKLISTED:192.168.10.10
IPS_DRY_RUN would block source_ip=192.168.10.10
```

No iptables rules are added in dry-run mode.

## Test 2: Enforce IPS for direct ping to IDS

1. Run IDS in enforce mode with short block time:

```bash
sudo .venv/bin/python main.py --iface eth0 --ips-mode enforce --block-seconds 60 --debug-packets --bpf icmp
```

2. From attacker VM:

```bash
ping 192.168.10.1
```

Expected IDS output:

```text
IPS_BLOCK_APPLIED chain=INPUT source_ip=192.168.10.10
IPS_BLOCK_APPLIED chain=FORWARD source_ip=192.168.10.10
```

After the rule is applied, pings to the IDS interface should stop replying.

3. Check rules on IDS machine:

```bash
sudo iptables -S INPUT | grep IDS_IOC_BLOCK
sudo iptables -S FORWARD | grep IDS_IOC_BLOCK
```

## Test 3: Wait for automatic unblock

If you used:

```bash
--block-seconds 60
```

Wait 60 seconds. You should see:

```text
IPS_BLOCK_REMOVED chain=INPUT source_ip=192.168.10.10
IPS_BLOCK_REMOVED chain=FORWARD source_ip=192.168.10.10
```

## Test 4: Stop IDS cleanup

By default, the program removes rules it added when you stop it.

Stop with:

```text
Ctrl + C
```

Then check:

```bash
sudo iptables -S INPUT | grep IDS_IOC_BLOCK
sudo iptables -S FORWARD | grep IDS_IOC_BLOCK
```

If nothing appears, cleanup worked.

## Manual cleanup if needed

If a rule remains, remove it manually:

```bash
sudo iptables -D INPUT -s 192.168.10.10 -m comment --comment IDS_IOC_BLOCK -j DROP
sudo iptables -D FORWARD -s 192.168.10.10 -m comment --comment IDS_IOC_BLOCK -j DROP
```

Repeat the command if the same rule exists more than once.

## Test 5: Blacklisted port with IPS dry-run

1. Add a blacklisted port:

```bash
nano data/blacklist_ports.csv
```

Example:

```csv
port
4444
```

2. Run IDS:

```bash
sudo .venv/bin/python main.py --iface eth0 --ips-mode dry-run --debug-packets
```

3. From attacker VM:

```bash
nc -vz 192.168.10.1 4444
```

Expected output:

```text
DST_PORT_BLACKLISTED:4444
IPS_DRY_RUN would block source_ip=192.168.10.10
```
