# Phase 4: Deep-learning model integration

## What we have

The uploaded doctor model is a CICIDS2017 multiclass model.

- Model file: `models/CICIDS_baseline (2).h5`
- Input shape: 72 numeric features
- Output shape: 9 classes
- Class labels are in `models/Mapping`
- Training/test CSVs are already numeric/preprocessed feature tables

Classes:

| ID | Label |
|---:|---|
| 0 | BENIGN |
| 1 | DoS Hulk |
| 2 | PortScan |
| 3 | DDoS |
| 4 | DoS GoldenEye |
| 5 | FTP-Patator |
| 6 | SSH-Patator |
| 7 | DoS slowloris |
| 8 | DoS Slowhttptest |

## Important limitation

This model is not a single-packet model.

It expects 72 CICIDS2017 flow features, such as flow duration, packet counts, IAT statistics, flag counts, and packet length statistics.

So we cannot correctly feed it only this packet information:

```text
src_ip, dst_ip, protocol, src_port, dst_port, packet length
```

That is only 4–6 packet-level fields. The model needs a full flow-level vector of 72 values.

## Phase 4 step 1: offline model validation

Run the model on the included sample CSV:

```bash
cd ~/Desktop/IDS
source .venv/bin/activate
pip install -r requirements.txt
python offline_model_test.py \
  --model "models/CICIDS_baseline (2).h5" \
  --csv models/sample_test_CICIDS2017_1000.csv \
  --features models/cicids_feature_columns.json \
  --mapping models/Mapping \
  --rows 1000
```

Expected result: the script prints accuracy, a confusion matrix, and sample predictions.

## Phase 4 step 2: full uploaded test CSV

Copy the full uploaded test CSV into `models/`, then run:

```bash
python offline_model_test.py \
  --model "models/CICIDS_baseline (2).h5" \
  --csv models/test_CICIDS2017Multiclass_NumericFS.csv \
  --features models/cicids_feature_columns.json \
  --mapping models/Mapping \
  --rows 0
```

`--rows 0` means use all rows.

## Phase 4 step 3: live IDS integration

Live integration requires a flow feature extractor.

Next we need to build:

```text
packets -> flows -> 72 CICIDS features -> model prediction -> ML alert
```

Also, the live feature values must use the same preprocessing/normalization as the training CSV. If the doctor has a scaler/preprocessor file, such as `preprocessor.pkl`, `scaler.pkl`, or `minmax.pkl`, it should be used.

Without the same scaler, live predictions may run but may not be reliable.
