# ML-only Slow HTTP / Slowloris detection

This version keeps the separate scan detector removed. Slow HTTP / Slowloris alerts come from the CICIDS neural-network model output.

Why a change was needed:
- The lab slow HTTP script opens many TCP sockets to one web service.
- With normal five-tuple flow grouping, every socket becomes a tiny flow and the model often predicts BENIGN.
- This version uses service-level ML grouping: source IP -> destination IP:HTTP port.
- The feature extractor then gives the model one CICIDS-compatible slow-HTTP vector.

Default runner settings:

```bash
sudo ./run_real_life_ids.sh eth0
```

Important defaults:
- `--ml-flow-key-mode service`
- `--ml-http-remap-ports 8080,8000,8443`
- `--flow-active-timeout 30`
- `--flow-idle-timeout 90`

Expected output during the lab slow HTTP test:

```text
ML_PREDICTION ... class=DoS Slowhttptest ...
ML_ALERT ... ML_CLASS:DoS Slowhttptest ...
```

This is still ML-only alerting. The feature calibration does not write alerts by itself; it only fixes the live CICIDS features sent to `model.predict()`.
