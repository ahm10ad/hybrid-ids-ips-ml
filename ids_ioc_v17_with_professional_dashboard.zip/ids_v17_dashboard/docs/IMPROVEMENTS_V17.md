# IDS v17 — Graduation Project Improvements

## What was added and why

### Tier 1 — Quick Wins

#### 1. ICMP Filter in ML Pipeline (`ml_engine.py`)
The CICIDS2017 model was trained on TCP/UDP flows only. ICMP has no ports,
no TCP flags, and no meaningful session structure. Sending ICMP packets to
the ML model produces garbage predictions and wastes CPU.

**Fix:** Any flow with `protocol == ICMP` is returned immediately in
`process_finalized_flow()` before feature extraction or model inference.
IOC blacklist detection still processes ICMP normally.

#### 2. Per-Class ML Thresholds (`ml_engine.py`)
A single global threshold (e.g. 0.60) is too strict for some attack classes
and too loose for others. The live normalizer produces weaker confidence
scores for some classes (e.g. DoS Hulk, PortScan) because the normalizer
was not trained on those specific feature distributions.

**Fix:** `DEFAULT_PER_CLASS_THRESHOLDS` in `ml_engine.py` maps each known
CICIDS attack class to its own confidence threshold. The global `--ml-threshold`
is used as a fallback for unknown classes.

#### 3. Flow Rate Statistical Guard (`flow_rate_guard.py`)
Attacks like HULK DDoS and UDP floods may produce many short flows that the
CICIDS model sees as BENIGN because individual flows look normal. A simple
packets-per-second and bytes-per-second check over a sliding window catches
these regardless of ML confidence.

**Why it matters for graduation:** This layer catches attacks the model
has never seen — any tool that generates high packet or byte rates triggers
it. It demonstrates defense-in-depth and statistical reasoning independent
of ML.

---

### Tier 2 — Core Contribution

#### 4. Isolation Forest Anomaly Detector (`anomaly_engine.py`)
An `IsolationForest` model trained on YOUR normal traffic. Any flow that
looks statistically unusual compared to your baseline triggers an
`ANOMALY_ISOLATION_FOREST` alert, even if the CICIDS model classifies it
as BENIGN.

**Training steps:**
```bash
# Step 1: capture normal traffic features
sudo python main.py --iface eth0 --ml-mode features-only \
    --alerts logs/normal_flows.jsonl

# Step 2: train the model
python anomaly_engine.py --train \
    --normal-log logs/normal_flows.jsonl \
    --model-out models/isolation_forest.pkl

# Step 3: restart IDS — model auto-loads
sudo ./run_ml_only_ids.sh eth0
```

**Academic framing:** "Hybrid supervised + unsupervised detection combining
a CICIDS2017 deep learning classifier with an Isolation Forest anomaly
detector trained on environment-specific baseline traffic."

#### 5. Smart Flow Key Mode Per Port (`ml_engine.py`)
`service` mode (src IP → dst IP:port) is optimal for Slowloris and HULK
because many TCP connections from the same source to the same service port
are grouped into one CICIDS feature vector.

`five-tuple` mode is better for port scans and exploit flows because each
unique 5-tuple is its own flow.

**Fix:** `smart_flow_key_mode()` automatically uses `service` mode for
known web ports (80, 443, 8080, 8000, 8443, etc.) and `five-tuple` for
everything else. No manual switching needed.

---

### Tier 3 — Professional Grade

#### 6. Alert Correlation Engine (`correlation_engine.py`)
Combines weak signals from the same source IP into stronger, escalated alerts.

**Rules implemented:**
| Rule | Result |
|------|--------|
| ML alert + IOC blacklist from same source | CRITICAL |
| Rate flood + ML alert from same source | CRITICAL |
| 10+ unique destination IPs in 60s | HIGH (scan detected) |
| 3+ ML probability guard alerts from same source | HIGH |
| Anomaly + ML alert from same source | CRITICAL |

**Why it matters:** A single ML alert at 0.55 confidence might be a false
positive. The same ML alert combined with a rate flood from the same IP
within 30 seconds is almost certainly a real attack. Correlation reduces
false positives while catching real multi-stage attacks.

---

## Detection Coverage Summary

| Attack | Before v17 | After v17 |
|--------|-----------|----------|
| Slow HTTP / Slowloris | ML (tuned) | ML + Anomaly + Correlation |
| HULK DDoS | ML (uncertain) | ML + Rate Guard + Anomaly |
| Port Scan | ML only | ML + Correlation (scan rule) |
| Unknown DDoS tools | Not covered | Rate Guard + Anomaly |
| ICMP flood | Rate guard (no ML) | IOC + Rate Guard (ML correctly skipped) |
| Multi-stage attacks | No correlation | Correlation → CRITICAL alert |
